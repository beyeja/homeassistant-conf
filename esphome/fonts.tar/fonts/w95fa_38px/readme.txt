Questions about license?
See more details at https://fontsarena.com/licenses-explained/